# NODE7 Physical Card Asset Pack

This package contains **51 real visual card assets** placed inside the original `node7-ui` resource.

## What these are

- Transparent PNG card frames ready to layer over dynamic item artwork.
- Editable SVG source versions of every frame.
- Matching alpha masks for clipping card content.
- Physical shared components such as corners, header plates, price chips, buttons, badges, stamps, and dividers.
- Preview contact sheets only for browsing the assets.

## Folders

- `html/assets/cards/png/` — production PNG frames.
- `html/assets/cards/svg/` — editable vector frames.
- `html/assets/cards/masks/` — matching masks.
- `html/assets/cards/components/` — reusable physical UI pieces.
- `html/assets/cards/previews/` — contact sheets.
- `html/assets/cards/manifest.json` — exact dimensions and transparent media-window coordinates.

No card data, shop logic, JavaScript library, or fake listing system was added. These are physical art assets only.
